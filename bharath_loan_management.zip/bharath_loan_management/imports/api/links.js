import { Mongo } from 'meteor/mongo';

export default Links = new Mongo.Collection('links');