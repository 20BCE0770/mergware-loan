import { Mongo } from 'meteor/mongo';

export default Loans = new Mongo.Collection('loans');