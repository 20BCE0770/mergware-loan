module.export({MongoObject:()=>MongoObject});let MongoObject;module.link('./mongo-object.js',{default(v){MongoObject=v}},0);module.link('./util.js',{appendAffectedKey:"appendAffectedKey",cleanNulls:"cleanNulls",expandKey:"expandKey",extractOp:"extractOp",genericKeyAffectsOtherGenericKey:"genericKeyAffectsOtherGenericKey",isBasicObject:"isBasicObject",keyToPosition:"keyToPosition",makeKeyGeneric:"makeKeyGeneric",reportNulls:"reportNulls"},1);


module.exportDefault(MongoObject);
